#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""doc_type_gate.py — `01_project_control/` 문서의 **유형 선언과 유형별 불변식**을 강제한다.

[2026-08-18 O83-D 신설 · `R1-6-16` 의 집행 장치]

🔴 왜 필요한가
--------------------------------------------------------------------------
`R1-6-14`(갱신형 용량 아키텍처)와 `R1-6-15`(append형 꼬리 롤오버)는 **유형별로 다른
처리**를 규정한다. 그런데 어떤 문서가 어떤 유형인지가 **어디에도 기계로 적혀 있지 않았다.**
⇒ 다음 세션은 유형을 **추측**하게 되고, 추측이 틀리면:
  * append형에 재균형을 돌려 **조각 불변성을 깬다**(인용 좌표가 매번 무효화된다).
  * 갱신형을 꼬리 롤오버로 다루어 **중간 삽입에서 조각이 터진다**.
🔴 이 세션에서 「추측」이 이미 두 번 사고를 냈다(폴더명 stem 추측 · 자동 분류 시도 3/4 불일치).
⇒ 유형은 **선언**하고, 이 게이트가 **선언 누락과 불변식 위반을 차단**한다.

정본 = `01_project_control/00_INDEX_이슈원장.md` §0 **「문서 유형 등재표」**
--------------------------------------------------------------------------
표 형식 = `| 문서 | 유형 | 근거 | 처리 |` · 유형 값 = `갱신형` | `append형` | `정적`.
분할 문서는 **허브 파일명**으로 선언한다(조각은 소속 문서에 귀속된다).

검사 축 4종
--------------------------------------------------------------------------
1. **선언 분모** — `01_project_control/` 의 모든 문서가 등재표에 있어야 한다.
   🔴 미선언 1건이라도 있으면 FAIL. 분모가 조용히 좁아지면 게이트가 착시가 된다(`P106`).
2. **상한** — 모든 조각(및 미분할 문서)이 `300줄 AND 40KB` 이내여야 한다(`R1-6-1`).
3. **갱신형 여유** — 조각 최대 크기가 `40KB × (1 - MIN_FREE)` 이하여야 한다.
   🔴 갱신형은 신규 행이 **같은 조각**에 떨어지므로 여유가 없으면 **다음 편집에서 확정 초과**다
   (실측: 인덱스 `-001` 여유 178B ↔ 세션당 추가 ≈1,200B) ⇒ 여유 부족은 **경고**로 조기 통보한다.
4. **append형 꼬리 여유** — 꼬리 조각(또는 미분할 파일)에 여유가 있어야 한다.
   append형은 꼬리만 자라므로 **꼬리 1개**만 보면 된다(비꼬리 조각은 불변이 정상이다).

⚠️ 3·4 는 **경고(관측)** 이고 1·2 는 **차단(FAIL)** 이다.
   여유 부족은 「지금 깨졌다」가 아니라 「다음에 깨진다」이므로 차단하면 정상 작업을 막는다.
   단 **경고를 0으로 만드는 것이 이 아키텍처의 목표**다 — 경고가 쌓이면 재균형·은퇴를 돌려라.
"""

import argparse
import io
import os
import re
import sys

ROOT = __import__('kit_paths').ROOT  # [kit] 루트 = kit_paths.py
DOC_DIR = os.path.join(ROOT, '01_project_control')
INDEX = os.path.join(DOC_DIR, '00_INDEX_이슈원장.md')

# 🔴 [2026-08-18 O83-E] 분모를 `01_project_control/` 밖으로 넓힌다.
#   **왜**: 분모가 `01_project_control/` 뿐이라 **매 세션 반드시 읽는 두 문서**가 검사 밖이었다 —
#   `00_guides/…` 는 이 세션에서 조문 8개를 더해 **426줄 / 45,116B** 까지 커졌는데
#   게이트가 **한 번도 경고하지 않았다**(사람이 python 으로 따로 재서 발견했다).
#   `R1-6-8`(분모를 넓혀라)의 3번째 재발이고, 이번엔 **게이트 자신의 분모**였다.
#   ⇒ 상시 독해 문서는 폴더 밖이라도 명시 편입한다. 이 목록은 **손으로 유지**한다
#   (glob 로 워크스페이스 전체를 넣으면 산출물·백업까지 들어와 게이트가 상시 빨강이 된다 · `P130`).
EXTRA_DOCS = [
    '00_guides/00_작업지침_세션운영규칙.md',
    '00_guides/01_문서분할_규약.md',
    '00_guides/02_파일쓰기_안전규약.md',
    #   🆕 [2026-09-21 O173] `R3` 무변경 이관 신설(처방 = O172-C-4 ㉠안 · 지연 로드 문서).
    '00_guides/04_단계종료_게이트.md',
    # 🆕 [2026-09-16 O167] `init_ihcho` 스킬 정본 — 스킬은 이 문서의 산출물이다(빌더·검증기 경유).
    '00_guides/03_init_ihcho_스킬_정본.md',
    '00_guides/03_init_ihcho_스킬_본문.md',   # 🆕 [O167] 스킬 본문(빌더 추출 대상)
    '00_guides/03_init_ihcho_스킬_참조_세션종료.md',   # 🆕 [O167] 스킬 참조(references/session-end.md 정본)   # [O85] R1-7 무변경 이관 신설
    '00_guides/03_init_ihcho_스킬_개발이력.md',   # 🆕 [O194] 스킬 개발이력(append · 경위 이관처)
    '01_project_control/99_NEXT_SESSION.md',
    #   🆕 🔴🔴 [2026-09-16 O165-B 편입] Inspection 절차 정본 — **분모 밖이어서 실사고를 놓쳤다.**
    #     O165 가 `edit` 앵커로 그 문서 `## ▣ 5` 제목을 삼키고 **꼬리 36줄(§6·§7)까지 소실**시켰는데
    #     게이트 6종이 전부 🟢 를 유지했다. 🔴 `R1-6-18 ④` 는 **분모 4곳**을 요구하는데
    #     O165 는 `doc_heading_gate.DOCS` **한 곳만** 넣었다(같은 결함의 자기 재발).
    #     ⇒ 이 편입은 그 나머지 3곳(여기 · `doc_line_length_gate.CANON` · `doc_census.SINGLES`)의 하나다.
    #     🔴 원장 §0 유형 등재표에도 행을 넣어야 축1 이 통과한다(선언 분모 ↔ 실재 분모는 짝이다).
    '30_operate/33_account_bootstrap/11_O누적작업_점검_재현_절차.md',
]

MAX_LINES = 300
MAX_BYTES = 40 * 1024
MAX_CHARS = 40000        # `read` 출력 한도 실측 근거(O82-C · doc_line_length_gate.READ_OUTPUT 과 동일)
MIN_FREE = 0.20          # 갱신형·append형 꼬리에 요구하는 최소 여유 비율(= 8KB)

# 🔴 [2026-08-18 O83-E] **줄 수 축은 「조각」에만 차단으로 적용한다.**
#   왜: `read` 도구 한도는 **2,000줄/호출**이고 O82-C 가 측정한 실패 경계는 **문자(~40,000)·
#   바이트(37.6~71.6KB)** 축이었다. 300줄은 *성공 사례의 우연한 속성*이지 측정된 경계가 아니다.
#   실측 반례: 지침이 **377줄 / 21,695자 / 39,269B** 인데 **1회 반환에 성공**한다
#   ⇒ 줄 수로 차단하면 **정상 문서를 FAIL** 시킨다.
#   🔴 게다가 `R1-5-3`(긴 문장을 의미 단위로 개행하라)이 줄 수를 **의도적으로 늘린다** ⇒
#   두 조문이 서로 밀어낸다. 짧은 줄로 잘 쓴 문서가 줄 수 상한에 걸리는 것은 규칙 설계 오류다.
#   ⇒ 조각은 도구가 만드는 산출물이라 300줄을 granularity 관례로 유지하고,
#     **비분할 정본·허브는 바이트·문자 축으로만 차단**한다(줄 수는 관측).
#   ⚠️ 이것은 「내 실패를 없애려고 상한을 푼 것」이 아니다 — 실제로 나를 물었던 **바이트 축(45,116B)
#     은 차단으로 유지**하고, 근거 없는 축만 관측으로 내렸다.
CHUNK_RX = re.compile(r'-\d{3}\.[A-Za-z]+$')

KINDS = ('갱신형', 'append형', '증분형', '정적', '자동생성')
# 🆕 🔴🔴 [2026-09-22 O180-B 신설 · 사용자 결정] **`증분형`** — 항목 본문은 append 인데
#   판정 줄만 제자리 갱신되는 문서. 대상 = `20_현업확인_요청.md` · `50_dbt_파이프라인_미결조치.md`.
#   🔴 왜 별 유형인가 = **두 축이 서로 다른 조각에서 일어난다**:
#     ㉠ 신규 문항·절은 **꼬리로만** 간다 ⇒ 여유 판정은 append형과 같아야 한다(꼬리 기준).
#     ㉡ 회신·종결이 오면 **과거 조각의 판정 줄**(`**판정**:` · 제목 이모지)을 고친다
#        ⇒ append형의 「비꼬리 조각 불변」 불변식이 거짓이다.
#   🔴🔴 갱신형으로 두면 **처방이 틀린다** — 상한 초과에 `--rebalance` 를 권하는데 그것은
#     조각 번호를 밀어 타 문서의 `-0NN.md:행` **인용 좌표를 전부 깨뜨린다**.
#     🔎 실사고 2건 = O179 가 문서20 `-010` 을, O180 이 문서50 `-023` 을 **수기 신설**해
#       `--rebalance` 를 피했다 ⇒ **관례가 도구를 앞질렀고 도구가 틀린 처방을 계속 냈다.**
#   🟢 처리 = 신규 항목 `--rollover` · 판정 갱신은 그 조각 `edit` · 🔴 `--rebalance` 금지.
#   🔴 **이 게이트는 여유 축만 담당한다** — 연산 차단은 `split_doc.py` 가 한다
#     (실측 = `split_doc.py` 는 이 등재표를 **읽지 않았다** ⇒ 선언만으로는 아무것도 막지 못했다).
#   정본 = 원장 §0 유형 등재표 · 음성 축 = `scripts/test_doc_type_increment.py`.
INCREMENTAL = '증분형'
#: 꼬리 기준으로 여유를 보는 유형 = 신규 항목이 꼬리에만 떨어지는 것들.
TAIL_KINDS = ('append형', INCREMENTAL)
# 🆕 🔴🔴 [2026-09-17 O170 신설] **`자동생성`** — 도구가 통째로 다시 쓰는 문서.
#   대상 = 허브 전종 · `00_선택표.md`(조각 폴더 사이드카) · `00_BRIEF.md` · `92_실측필요_후속작업.md`.
#   🔴 왜 별 유형인가 = 처리가 셋과 **다르다**:
#     ㉠ **손으로 고치지 않는다**(고치면 다음 재발행에서 조용히 사라진다)
#     ㉡ **분할하지 않는다** — 색인을 쪼개면 「어느 조각을 읽을지」를 못 고른다
#     ㉢ 상한에 닿으면 재균형·은퇴가 아니라 **밀도(항목 캡)를 내린다**
#     ㉣ **인용 정본이 아니다**(절단·캡이 있다).
#   ⇒ 그래서 여유 판정(`MIN_FREE`)은 **경고로만** 본다 — 갱신형처럼 「다음 편집에서 확정 초과」가
#     아니고, 사람이 그 파일에 행을 더하지 않기 때문이다. 정본 = `R1-6-26`.
AUTOGEN = '자동생성'

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def read_text(p):
    with io.open(p, encoding='utf-8') as fh:
        return fh.read()


def nbytes_of(p):
    """파일의 **실제 바이트 수**(stat 비의존 · `R3-9 ㉡`).

    🆕 [2026-09-08 O143] 정본 근거·경위 = `doc_census.nbytes_of` docstring.
      🔴 `os.path.getsize` 를 쓰면 스테이지 마운트의 cold stat 이 **블록 반올림값**을 낼 수 있고,
        이 게이트에서는 그것이 **여유 과소 → 불필요한 재균형 유도**로 이어진다.
    """
    with io.open(p, 'rb') as fh:
        return len(fh.read())


def index_logical():
    """인덱스는 분할돼 있으므로 허브+조각을 이어붙여 읽는다(등재표가 조각에 있다)."""
    from split_doc import collect_bodies, hub_outdir
    parts, _paths = collect_bodies(INDEX, hub_outdir(INDEX))
    return '\n'.join([read_text(INDEX)] + parts)


def parse_registry(text):
    """§0 문서 유형 등재표 → {문서명: (유형, 처리)}."""
    reg = {}
    in_tbl = False
    for line in text.split('\n'):
        s = line.strip()
        if s.startswith('| 문서 | 유형 |'):
            in_tbl = True
            continue
        if in_tbl:
            if not s.startswith('|'):
                in_tbl = False
                continue
            if set(s.replace('|', '').replace('-', '').replace(':', '').strip()) == set():
                continue
            cells = [c.strip() for c in s.strip('|').split('|')]
            if len(cells) < 2:
                continue
            name = cells[0].replace('`', '').replace('*', '').strip()
            kind = None
            for k in KINDS:
                if k in cells[1]:
                    kind = k
                    break
            if name and kind:
                reg[name] = (kind, cells[3] if len(cells) > 3 else '')
    return reg


def hub_of(name):
    m = re.match(r'^(.*)-\d{3}(\.[A-Za-z]+)$', name)
    return (m.group(1) + m.group(2)) if m else name


def actual_docs():
    """실재 문서(허브 단위) → 소속 파일 목록. `01_project_control/` + `EXTRA_DOCS`(폴더 밖 상시 독해)."""
    fam = {}
    for root, dirs, files in os.walk(DOC_DIR):
        #   🆕 [O277] 원장 폴더 = `01_project_control/` 는 작업기록(`98_worklog/`)도 품는다 — 그것은 원장 문서가 아니다
        dirs[:] = [d for d in dirs if d not in ('_archive', '__pycache__', '98_worklog')]
        for f in sorted(files):
            if not f.endswith(('.md', '.sql')):
                continue
            fam.setdefault(hub_of(f), []).append(os.path.join(root, f))
    for rel in EXTRA_DOCS:
        p = os.path.join(ROOT, rel)
        if not os.path.exists(p):
            continue
        hub = hub_of(os.path.basename(p))
        fam.setdefault(hub, []).append(p)
        # 그 문서의 형제 조각도 함께 편입한다(`99_NEXT_SESSION-001.md` 등)
        stem, ext = os.path.splitext(p)
        n = 1
        while True:
            c = '%s-%03d%s' % (stem, n, ext)
            if not os.path.exists(c):
                break
            fam[hub].append(c)
            n += 1
        # 🆕 [2026-09-01 O129-B] **폴더 방식 조각도 편입한다** (`<이름>_조각/` · `R1-6-21`).
        #   🔴 왜: O107 이 `--to-outdir` 로 형제 → 폴더 이전을 도입했고 `99_NEXT_SESSION` 이 그 방식이다.
        #   그런데 위 형제 루프만 있어서 이 게이트는 그 문서를 **허브 1개**로 셌다 ⇒ 조각 24개가
        #   **분모 밖**이었고, 실측 여유 34 B 인 조각을 게이트는 6,503 B 로 보고했다(`R1-6-25` 유형).
        #   🔴 O107 이 남긴 「이전 후 손으로 고칠 분모」 목록에 **이 게이트가 빠져 있었다** —
        #   목록 자체가 분모였고 그 분모가 불완전했다. ⇒ 이제 두 방식을 **둘 다** 본다.
        chunk_dir = os.path.join(os.path.dirname(p),
                                 os.path.basename(stem) + '_조각')
        if os.path.isdir(chunk_dir):
            # 🆕 🔴 [2026-09-17 O172 · 의도적 **편입** — 여기만 전건을 본다]
            #   이 게이트는 「조각 수」가 아니라 **상한(300줄 AND 40KB)** 을 재므로 폴더의
            #   **사이드카·인수인계 라벨 파일까지 전건 검사하는 것이 옳다** — 상한 초과는 파일 종류와
            #   무관하게 `read` 전량 확보를 깨뜨린다.
            #   🔴 그러므로 `doc_census.chunk_rx`(조각만) 와 **분모가 다른 것은 결함이 아니라 설계**다.
            #     🟢 판정식 = **「같은 것을 다르게 재지 마라」는 「다른 것을 같게 재라」가 아니다** —
            #       세는 대상이 다르면(조각 수 ↔ 상한 준수) 분모도 달라야 하고, 그 차이를 **적어야** 한다
            #       (적지 않은 차이가 조각 수 35 ↔ 36 불일치였다).
            for f in sorted(os.listdir(chunk_dir)):
                if f.endswith(('.md', '.sql')):
                    fam[hub].append(os.path.join(chunk_dir, f))
    #   🆕 [O277] `99_NEXT_SESSION` 은 이제 `01_project_control/` 안에 있어 순회와 EXTRA_DOCS 가 같은 파일을 두 번 싣는다 ⇒ 중복 제거
    return {h: list(dict.fromkeys(ps)) for h, ps in fam.items()}


def nlines(p):
    t = read_text(p)
    return t.count('\n') + (0 if t.endswith('\n') else 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--strict', action='store_true',
                    help='여유 경고도 FAIL 로 올린다(단계 종료 게이트용)')
    a = ap.parse_args()

    reg = parse_registry(index_logical())
    fam = actual_docs()
    fails, warns = [], []

    print('[문서 유형 게이트] 등재 %d건 · 실재 문서 %d건' % (len(reg), len(fam)))

    # ── 축 1: 선언 분모 ────────────────────────────────────────────────
    # 🔴 등재표는 파일명을 축약(`41_…_BRONZE_DDL.sql`)하거나 **경로 포함**(`00_guides/…`)으로
    #   적을 수 있다. 게이트는 **파일명 기준**으로 조회하므로 세 형태를 모두 허용한다.
    #   (O83-E 실측: 경로 포함으로 등재했더니 「미선언」으로 잡혔다 — 표기 규칙 불일치 오탐.)
    def declared(name):
        if name in reg:
            return reg[name]
        for k, v in reg.items():
            if os.path.basename(k) == name:
                return v
            if '…' in k:
                head, tail = k.split('…', 1)
                if name.startswith(os.path.basename(head).strip()) and name.endswith(tail.strip()):
                    return v
        return None

    undeclared = [n for n in sorted(fam) if declared(n) is None]
    print('  축1 선언 분모: 미선언 %d건' % len(undeclared))
    for n in undeclared:
        print('    🔴', n)
    if undeclared:
        fails.append('유형 미선언 %d건 — 등재표(§0)에 추가하라' % len(undeclared))

    # ── 축 2~4 ────────────────────────────────────────────────────────
    over, tight, long_lines = [], [], []
    print('  %-42s %-8s %5s %9s %9s' % ('문서', '유형', '파일', 'max B', '여유 B'))
    for name in sorted(fam):
        d = declared(name)
        if d is None:
            continue
        kind = d[0]
        paths = fam[name]
        # 허브는 자동 생성물이라 상한 판정에서 제외하지 않는다(read 대상이므로 함께 본다)
        # 🆕 🔴🔴 [2026-09-08 O143] `os.path.getsize`(stat) 금지 — **읽은 바이트 수**로 잰다.
        #   근거·경위 = `doc_census.nbytes_of` docstring(스테이지 마운트의 cold stat 이
        #   16바이트 블록 반올림값을 낸 실관측 1건 · 지침 `R2-5` 가 이미 경고한 함정).
        #   🔴 여기서 stat 을 쓰면 크기가 **과대**로 잡혀 여유가 과소가 되고,
        #     상한 근처 문서에서 **불필요한 재균형**(파괴 가능 유지 연산)을 유도한다.
        sizes = [(p, nbytes_of(p)) for p in paths]
        mx_p, mx = max(sizes, key=lambda x: x[1])
        for p, b in sizes:
            t = read_text(p)
            nl = t.count('\n') + (0 if t.endswith('\n') else 1)
            bad = []
            if b > MAX_BYTES:
                bad.append('%d B > 40KB' % b)
            if len(t) > MAX_CHARS:
                bad.append('%d 자 > %d' % (len(t), MAX_CHARS))
            if CHUNK_RX.search(os.path.basename(p)) and nl > MAX_LINES + 1:
                bad.append('%d 줄 > %d (조각)' % (nl, MAX_LINES))
            elif nl > MAX_LINES + 1:
                long_lines.append('%s (%d줄 · 관측)' % (os.path.relpath(p, ROOT), nl))
            if bad:
                over.append('%s: %s' % (os.path.relpath(p, ROOT), ' / '.join(bad)))

        if kind in TAIL_KINDS:
            # 🔴 꼬리만 본다 — append형은 비꼬리 조각이 **불변**이고,
            #   증분형은 비꼬리 조각이 **판정 줄만**(수십~수백 B) 바뀌므로
            #   「다음 편집에서 확정 초과」가 성립하지 않는다(신규 항목은 꼬리로만 간다).
            tail_p, tail_b = sorted(sizes)[-1] if len(sizes) == 1 else sorted(
                sizes, key=lambda x: x[0])[-1]
            free = MAX_BYTES - tail_b
            label, watch = '꼬리', free
        else:
            free = MAX_BYTES - mx
            label, watch = 'max', free
        print('  %-42s %-8s %5d %9s %9s%s' % (
            name, kind, len(paths), format(mx, ','), format(watch, ','),
            '  ← %s' % label if kind in TAIL_KINDS else ''))
        if kind != '정적' and watch < MAX_BYTES * MIN_FREE:
            tight.append('%s: %s 여유 %s B (< %d%%)'
                         % (name, label, format(watch, ','), MIN_FREE * 100))

    print('  축2 상한 초과(바이트·문자 · 조각은 줄 수도): %d건' % len(over))
    for x in over:
        print('    🔴', x)
    if over:
        # 🆕 🔴🔴 [2026-09-22 O180-B] **처방을 유형별로 가른다.**
        #   종전에는 전 유형에 `--rebalance` 를 권했는데 그것이 **증분형에는 틀린 처방**이다
        #   (조각 번호를 밀어 타 문서의 인용 좌표를 전부 깨뜨린다).
        #   🔎 실사고 2건 = O179 문서20 `-010` · O180 문서50 `-023` 이 이 처방을 **무시하고**
        #     수기 꼬리 조각을 만들었다 ⇒ 도구가 틀린 처방을 계속 내고 있었다.
        inc_over = [x for x in over
                    if any(x.startswith(os.path.relpath(
                        os.path.join(ROOT, n), ROOT).rsplit('.', 1)[0])
                        for n, (k, _h) in reg.items() if k == INCREMENTAL)]
        if inc_over:
            fails.append(
                '상한 초과 %d건 — 🔴 **증분형은 `--rebalance` 를 쓰지 마라**(인용 좌표 파괴) '
                '⇒ `--rollover` 로 꼬리 조각을 신설하라' % len(over))
        else:
            fails.append('상한 초과 %d건 — `--rebalance` 를 돌려라' % len(over))

    if long_lines:
        print('  ⚪ 300줄 초과(비분할 정본 · 관측만 · 근거 = 도구 한도 2,000줄): %d건' % len(long_lines))
        for x in long_lines:
            print('    ⚪', x)

    print('  축3·4 여유 부족(경고): %d건' % len(tight))
    for x in tight:
        print('    🟠', x)
    if tight:
        (fails if a.strict else warns).append(
            '여유 부족 %d건 — 갱신형은 `--rebalance`, 은퇴 가능하면 `retire_rows.py`' % len(tight))

    print('')
    if fails:
        print('🔴 게이트 실패 %d건' % len(fails))
        for f in fails:
            print(' -', f)
        return 1
    if warns:
        # 🆕 🔴 [2026-08-30 O123-D 시정] **두 축을 함께 낸다.**
        #   종전 = `경고 %d건` 이 `len(warns)`(= **메시지 수**)였는데 바로 위 상세는
        #   `여유 부족 2건`(= **항목 수**)을 냈다 ⇒ 한 도구의 출력 안에서
        #   **「경고 1건」과 「2건」이 동시에 보였다**(실측 · `R3-9 ㉡` 「같은 것을 다르게 재는 지점」).
        #   🔴 사람은 이것을 「경고가 1개」로 읽고 **한 문서만 손본다.**
        #   ⇒ 🟢 판정식 = 집계 단위가 둘이면 **둘 다 이름 붙여 출력**하라(하나를 고르면 반드시 오독된다).
        print('🟡 통과(경고 %d건 · 대상 항목 %d건)' % (len(warns), len(tight)))
        for w in warns:
            print(' -', w)
        return 0
    print('✅ 게이트 통과 — 선언 누락 0 · 상한 초과 0 · 여유 부족 0')
    return 0


if __name__ == '__main__':
    sys.exit(main())
